#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved.
#


GVTAP_AGENT_SERVER=$GVTAP_AGENT_PROG_DIR/uctvd
GVTAP_AGENT_CMD=$GVTAP_AGENT_PROG_DIR/uctvl
GVTAP_CONF_FILE="/etc/uctv/uctv.conf"

# UCT-V iface permission flags
MIRROR_DST=1
MIRROR_SRC_INGRESS=2
MIRROR_SRC_EGRESS=4


register_ifaces()
{
	while read -r LINE; do
		# Skip blank lines
		if [ ${#LINE} -eq 0 ]; then
			continue
		fi

		read -a WORD_ARRAY <<< $LINE

		# Skip commented lines
		if [[ ${WORD_ARRAY[0]:0:1} == "#" ]]; then
			continue
		fi

		LEN=${#WORD_ARRAY[*]}
		if [ $LEN -lt 2 ]; then
			echo "Error: Missing interface/permission in $GVTAP_CONF_FILE"
			return 1
		fi

		# Extract iface name
		FIRSTWORD=${WORD_ARRAY[0]}

		NOT_IFACE=0
		case $FIRSTWORD in
		  tunnel-src)
		  NOT_IFACE=1
		  ;;
		  tunnel-gw)
		  NOT_IFACE=1
		  ;;
                  tunnel-src-v6)
                  NOT_IFACE=1
                  ;;
                  tunnel-gw-v6)
                  NOT_IFACE=1
                  ;;
		  ovs-agent-mode)
		  NOT_IFACE=1
		  ;;
		  ovs-egress-if)
		  NOT_IFACE=1
		  ;;
		  ovs-vlan-tag)
		  NOT_IFACE=1
		  ;;
		  *)
		  IFACE=$FIRSTWORD
		  ;;
		esac
		
		if [ $NOT_IFACE -eq 1 ]; then
 			echo "Msg: skipping ($FIRSTWORD)... not an interface to register."
			continue
		fi

		# Extract iface permissions
		PERMS=0
		for (( OFF=1; OFF<=(($LEN - 1)); OFF++ )); do
			PERM=${WORD_ARRAY[$OFF]}
			case $PERM in
				"mirror-dst")
					(( PERMS=(( $PERMS | $MIRROR_DST )) ))
					;;
	
				"mirror-src-ingress")
					(( PERMS=(( $PERMS | $MIRROR_SRC_INGRESS )) ))
					;;
	
				"mirror-src-egress")
					(( PERMS=(( $PERMS | $MIRROR_SRC_EGRESS )) ))
					;;
	
				*)
					echo "Error: Invalid permission in $GVTAP_CONF_FILE"
					return 1
					;;
			esac
		done

		# Perform iface registration
		$GVTAP_AGENT_CMD iface-reg $IFACE $PERMS
		if [ $? -ne 0 ]; then
			echo "Error: Could not register interface: $IFACE"
			return 1
		fi

	done < $GVTAP_CONF_FILE

	return 0
}


# Proceed iff UCT-V is not running
PID=`pidof $GVTAP_AGENT_SERVER`
if [ $PID > 0 ]; then
	echo "Error: UCT-V is (already) running"
	exit 1
fi

# Reset UCT-V
$GVTAP_AGENT_CMD uctv-ctl --reset
if [ $? -ne 0 ]; then
	echo "Error: UCT-V reset failure"
	exit 1
fi

# Start UCT-V
$GVTAP_AGENT_CMD uctv-ctl --start
if [ $? -ne 0 ]; then
	echo "Error: UCT-V start failure"
	exit 1
fi

# Wait for UCT-V to become ready
sleep 2

# Register ifaces with UCT-V
register_ifaces
if [ $? -ne 0 ]; then
	echo "Error: UCT-V interface registration failure" 
	exit 1
fi

exit 0
