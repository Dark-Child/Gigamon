#!/bin/bash

# This script sets up an enviornment, such that gvtap can be started
# from the build directory, without having to install a package.

cp uctv*.sh ../../../build/agent/linux
cp *ovs*.sh ../../../build/agent/linux
cp uctv.conf  ../../../build/agent/linux
cp env_setup ../../../build/agent/linux

cd ../../../build/agent/linux

sed -i 's/GVTAP_AGENT_SERVER\=/\. env_setup\n\nGVTAP_AGENT_SERVER\=/' uctv_start.sh
sed -i 's/\/etc\/uctv\//\.\//' uctv_start.sh

sed -i 's/GVTAP_AGENT_SERVER\=/\. env_setup\n\nGVTAP_AGENT_SERVER\=/' uctv_stop.sh

sed -i 's/GVTAP_AGENT_SERVER\=/\. env_setup\n\nGVTAP_AGENT_SERVER\=/' uctv_restart.sh

sed -i 's/GVTAP_AGENT_SERVER\=/\. env_setup\n\nGVTAP_AGENT_SERVER\=/' uctv_status.sh

mkdir uctv_data_dir
chmod 777 uctv_data_dir
