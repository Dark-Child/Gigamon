#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved.
#


GVTAP_AGENT_SERVER=$GVTAP_AGENT_PROG_DIR/uctvd


PID=`pidof $GVTAP_AGENT_SERVER`
if [ $PID > 0 ]; then
	echo "UCT-V is running"
else
	echo "UCT-V is not running"
fi

exit 0
